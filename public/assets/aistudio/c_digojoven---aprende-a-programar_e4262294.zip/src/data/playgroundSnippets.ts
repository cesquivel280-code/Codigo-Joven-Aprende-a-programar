export interface PlaygroundSnippet {
  id: string;
  title: string;
  description: string;
  tags: string[];
  code: string;
}

export const playgroundSnippets: PlaygroundSnippet[] = [
  {
    id: 'rpg-battle',
    title: 'Simulador de Batalla RPG',
    description: 'Enfrentamiento en tiempo real por turnos entre un Héroe y un Dragón usando números aleatorios.',
    tags: ['Bucles', 'Condicionales', 'Math.random'],
    code: `// --- SIMULADOR DE BATALLA RPG ---
let heroe = { nombre: "Aria la Valiente", hp: 120, ataqueMax: 30 };
let dragon = { nombre: "Ignis el Rojo", hp: 140, ataqueMax: 25 };

console.log(\`⚔️ ¡Comienza el combate: \${heroe.nombre} VS \${dragon.nombre}!\`);
console.log("--------------------------------------------------");

let turno = 1;
while (heroe.hp > 0 && dragon.hp > 0) {
  // Turno del héroe
  let dañoHeroe = Math.floor(Math.random() * heroe.ataqueMax) + 10;
  let esCritico = Math.random() > 0.7;
  if (esCritico) {
    dañoHeroe *= 2;
    console.log(\`⚡ ¡GOLPE CRÍTICO de \${heroe.nombre}! Infringe \${dañoHeroe} de daño.\`);
  } else {
    console.log(\`🗡️ \${heroe.nombre} ataca causando \${dañoHeroe} de daño.\`);
  }
  dragon.hp = Math.max(0, dragon.hp - dañoHeroe);

  // Turno del dragón si sigue vivo
  if (dragon.hp > 0) {
    let dañoDragon = Math.floor(Math.random() * dragon.ataqueMax) + 8;
    heroe.hp = Math.max(0, heroe.hp - dañoDragon);
    console.log(\`🔥 \${dragon.nombre} escupe fuego causando \${dañoDragon} de daño.\`);
  }

  console.log(\`[Turno \${turno}] \${heroe.nombre}: \${heroe.hp} HP | \${dragon.nombre}: \${dragon.hp} HP\`);
  console.log("--------------------------------------------------");
  turno++;
}

if (heroe.hp > 0) {
  console.log(\`🏆 ¡VICTORIA! \${heroe.nombre} ha derrotado al dragón y reclamado el tesoro legendario.\`);
} else {
  console.log(\`💀 DERROTA: \${dragon.nombre} ha defendido su guarida.\`);
}
`,
  },
  {
    id: 'number-guesser',
    title: 'Adivina el Número Secreto',
    description: 'Algoritmo de búsqueda binaria que adivina un número secreto en un rango entre 1 y 100.',
    tags: ['Algoritmos', 'Lógica', 'Búsqueda'],
    code: `// --- ADIVINADOR INTELIGENTE (BÚSQUEDA BINARIA) ---
const numeroSecreto = 73; // Cambia este número entre 1 y 100
let min = 1;
let max = 100;
let intentos = 0;
let encontrado = false;

console.log(\`🎯 Número secreto a encontrar: \${numeroSecreto}\`);

while (!encontrado && min <= max) {
  intentos++;
  let intentoIA = Math.floor((min + max) / 2);
  console.log(\`Intento #\${intentos}: La IA prueba con \${intentoIA}...\`);

  if (intentoIA === numeroSecreto) {
    console.log(\`🎉 ¡Encontrado! El número era \${intentoIA} en solo \${intentos} pasos.\`);
    encontrado = true;
  } else if (intentoIA < numeroSecreto) {
    console.log(\`   ⬆️ Demasiado bajo. El número es mayor.\`);
    min = intentoIA + 1;
  } else {
    console.log(\`   ⬇️ Demasiado alto. El número es menor.\`);
    max = intentoIA - 1;
  }
}
`,
  },
  {
    id: 'ascii-art',
    title: 'Generador de Patrones y Pirámides',
    description: 'Construye pirámides y patrones geométricos en texto utilizando bucles anidados.',
    tags: ['Bucles anidados', 'Strings', 'Patrones'],
    code: `// --- GENERADOR DE PIRÁMIDES Y PATRONES ---
function dibujarPiramide(altura) {
  console.log(\`✨ Pirámide de altura \${altura}:\`);
  for (let i = 1; i <= altura; i++) {
    let espacios = " ".repeat(altura - i);
    let bloques = "▲".repeat(2 * i - 1);
    console.log(espacios + bloques);
  }
}

dibujarPiramide(6);

console.log("\\n💎 Patrón de Diamante:");
for (let fila = 1; fila <= 5; fila++) {
  let linea = "";
  for (let col = 1; col <= 5; col++) {
    linea += (fila === col || fila + col === 6) ? "🔷 " : "▫️ ";
  }
  console.log(linea);
}
`,
  },
  {
    id: 'password-gen',
    title: 'Generador de Contraseñas Seguras',
    description: 'Crea claves ultraseguras combinando letras mayúsculas, minúsculas, números y símbolos aleatorios.',
    tags: ['Funciones', 'Arrays', 'Seguridad'],
    code: `// --- GENERADOR DE CONTRASEÑAS SEGURAS ---
function generarPassword(longitud = 12) {
  const caracteres = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*";
  let password = "";
  for (let i = 0; i < longitud; i++) {
    const indiceAleatorio = Math.floor(Math.random() * caracteres.length);
    password += caracteres[indiceAleatorio];
  }
  return password;
}

console.log("🔐 Generando 4 contraseñas de alta seguridad:");
for (let i = 1; i <= 4; i++) {
  let pass = generarPassword(14);
  console.log(\`Clave #\${i}: \${pass}\`);
}
`,
  },
  {
    id: 'minigame-puzzle-2d',
    title: 'Minijuego 2D: Laberinto y Puzzle de Acertijos',
    description: 'Minijuego interactivo de puzzle 2D en consola donde un explorador descifra acertijos, recoge llaves y supera el laberinto.',
    tags: ['Minijuegos', 'Puzzles', 'Juegos 2D', 'Acertijos'],
    code: `// --- MINIJUEGO 2D: LABERINTO, PUZZLE Y ACERTIJOS ---
// Demostración de lo que podés crear con JavaScript:
// Puzzles, juegos 2D, acertijos y aventuras interactivas.

const mapaLaberinto = [
  ["⬛", "⬛", "⬛", "⬛", "⬛", "⬛", "⬛"],
  ["⬛", "🤖", "▫️", "🗝️", "⬛", "🏆", "⬛"],
  ["⬛", "⬛", "▫️", "⬛", "⬛", "▫️", "⬛"],
  ["⬛", "❓", "▫️", "▫️", "🚪", "▫️", "⬛"],
  ["⬛", "⬛", "⬛", "⬛", "⬛", "⬛", "⬛"]
];

console.log("🗺️ ¡Bienvenido a la Aventura Interactiva!");
console.log("Objetivo: Recoger la llave 🗝️, responder el acertijo ❓ y abrir la puerta 🚪 hacia el trofeo 🏆.\\n");

console.log("--- MAPA DEL JUEGO 2D ---");
for (let fila of mapaLaberinto) {
  console.log(fila.join(" "));
}

let puntos = 50;
let vidas = 3;
let tieneLlave = true;
let acertijoResuelto = false;

console.log("\\n🤖 El jugador se mueve hacia la casilla 🗝️...");
console.log("✨ ¡Has recogido la Llave Dorada! (+25 puntos)");
puntos += 25;

console.log("\\n🧩 Llegaste a la casilla de Acertijo ❓...");
const pregunta = "¿Cuál es el comando estándar para imprimir en consola en JavaScript?";
const respuestaJugador = "console.log()";

console.log("Pregunta:", pregunta);
console.log("Respuesta:", respuestaJugador);

if (respuestaJugador === "console.log()") {
  console.log("✅ ¡Acertijo resuelto correctamente! (+50 puntos)");
  puntos += 50;
  acertijoResuelto = true;
} else {
  vidas -= 1;
  console.log("❌ Incorrecto. Vidas restantes:", vidas);
}

console.log("\\n🚪 Llegando a la Puerta Mágica...");
if (tieneLlave && acertijoResuelto) {
  console.log("🔓 ¡La puerta se desbloquea! Llegaste al trofeo 🏆.");
  console.log(\`🎉 ¡VICTORIA! Puntuación: \${puntos} pts | Vidas: \${vidas}/3\`);
  console.log("¡Así de fácil se crean minijuegos y puzzles con JavaScript!");
}
`,
  },
];
