import React, { useState } from 'react';
import { useGame } from '../context/GameContext';
import { playgroundSnippets, PlaygroundSnippet } from '../data/playgroundSnippets';
import { runCode } from '../utils/codeRunner';
import { ExecutionResult } from '../types/course';
import { sounds } from '../utils/soundEffects';
import { CodeEditor } from './CodeEditor';
import { ConsoleOutput } from './ConsoleOutput';
import { Terminal, Sparkles, BookOpen, Layers, Home, ArrowLeft } from 'lucide-react';

interface PlaygroundViewProps {
  onGoHome?: () => void;
}

export const PlaygroundView: React.FC<PlaygroundViewProps> = ({ onGoHome }) => {
  const { unlockBadge } = useGame();
  const [activeSnippet, setActiveSnippet] = useState<PlaygroundSnippet>(playgroundSnippets[0]);
  const [code, setCode] = useState(playgroundSnippets[0].code);
  const [isRunning, setIsRunning] = useState(false);
  const [executionResult, setExecutionResult] = useState<ExecutionResult | null>(null);

  const handleSelectSnippet = (snippet: PlaygroundSnippet) => {
    sounds.playClick();
    setActiveSnippet(snippet);
    setCode(snippet.code);
    setExecutionResult(null);
  };

  const handleRun = async () => {
    setIsRunning(true);
    sounds.playRun();
    const result = await runCode(code);
    setExecutionResult(result);
    setIsRunning(false);

    if (result.errors.length === 0) {
      sounds.playSuccess();
      unlockBadge('badge-explorador-playground');
    } else {
      sounds.playError();
    }
  };

  const handleReset = () => {
    setCode(activeSnippet.code);
    setExecutionResult(null);
    sounds.playClick();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
      {/* Top back button */}
      {onGoHome && (
        <div className="mb-4">
          <button
            onClick={onGoHome}
            title="Volver al inicio y mapa de cursos"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 hover:border-cyan-500/50 hover:bg-slate-800 text-slate-300 hover:text-white transition-all text-xs font-medium group"
          >
            <Home className="w-3.5 h-3.5 text-cyan-400 group-hover:-translate-x-0.5 transition-transform" />
            <span>Volver al Inicio</span>
          </button>
        </div>
      )}

      {/* Header */}
      <div className="mb-8 pb-6 border-b border-slate-800">
        <div className="flex items-center gap-2 text-xs font-semibold text-cyan-400 mb-1">
          <Terminal className="w-4 h-4" />
          <span>Laboratorio de Práctica Libre</span>
          <span aria-hidden="true">·</span>
          <span>Sin Restricciones ni Tests</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
          Sandbox y Proyectos Experimentales
        </h2>
        <p className="text-sm text-slate-400 mt-1 max-w-2xl">
          Escribe cualquier código JavaScript, prueba algoritmos, modifica proyectos de ejemplo o inventa tus propios mini-juegos en tiempo real.
        </p>
      </div>

      {/* Snippet Template Selector Tabs */}
      <div className="mb-6">
        <div className="text-xs font-semibold text-slate-400 mb-2.5 flex items-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>Plantillas de proyectos listas para ejecutar:</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {playgroundSnippets.map((snippet) => {
            const isSelected = snippet.id === activeSnippet.id;
            return (
              <button
                key={snippet.id}
                onClick={() => handleSelectSnippet(snippet)}
                className={`p-3.5 rounded-xl border text-left transition-all ${
                  isSelected
                    ? 'bg-slate-900 border-cyan-500 shadow-md shadow-cyan-500/10'
                    : 'bg-slate-950/80 border-slate-800 hover:border-slate-700 hover:bg-slate-900/50'
                }`}
              >
                <div className="font-bold text-xs sm:text-sm text-white mb-1">
                  {snippet.title}
                </div>
                <div className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed">
                  {snippet.description}
                </div>
                <div className="flex flex-wrap gap-1 mt-2.5">
                  {snippet.tags.map((tag) => (
                    <span
                      key={tag}
                      className="px-1.5 py-0.5 rounded text-[10px] bg-slate-800 text-slate-300 font-mono"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Editor & Console Split */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Editor Area (7 cols) */}
        <div className="lg:col-span-7 h-[460px]">
          <CodeEditor
            code={code}
            onChange={setCode}
            onRun={handleRun}
            onReset={handleReset}
            isRunning={isRunning}
          />
        </div>

        {/* Console & Inspector Area (5 cols) */}
        <div className="lg:col-span-5 flex flex-col gap-4">
          <ConsoleOutput
            result={executionResult}
            onClear={() => setExecutionResult(null)}
          />

          {/* Live Scope Variables Inspector */}
          {executionResult && Object.keys(executionResult.scope).length > 0 && (
            <div className="rounded-xl border border-slate-800 bg-slate-900/80 p-4">
              <div className="flex items-center gap-2 text-xs font-semibold text-cyan-400 mb-3">
                <Layers className="w-4 h-4" />
                <span>Inspector de Variables en Memoria</span>
              </div>
              <div className="space-y-1.5 max-h-48 overflow-y-auto font-mono text-xs">
                {Object.entries(executionResult.scope).map(([key, val]) => (
                  <div
                    key={key}
                    className="flex items-center justify-between p-2 rounded bg-slate-950 border border-slate-800/80"
                  >
                    <span className="text-cyan-300 font-semibold">{key}:</span>
                    <span className="text-slate-300 truncate max-w-[200px]">
                      {typeof val === 'object' ? JSON.stringify(val) : String(val)}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
